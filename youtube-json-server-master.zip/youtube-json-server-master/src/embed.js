console.log('Works')

document.write('Write works <br />')

document.write(`currentScript is ${document.currentScript} <br />`)
